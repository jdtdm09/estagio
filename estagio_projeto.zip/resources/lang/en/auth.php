<?php

return [
    'failed' => 'As credenciais não correspondem com o nosso sistema.',
];