<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        p {
            color: #555;
        }

        .qrcode {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>
    <p>Isto é o bilhete para o evento: <?php echo e($name); ?></p>
        <div class="qrcode" style="display: flex; justify-content: center; align-items: center; height: 100vh; text-align: center;">
            QrCode para a entrada no Evento.
            </br>
            </br>
            <div style="position: absolute; top: 36%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                <?php echo DNS2D::getBarcodeHTML("$qrcode", 'QRCODE'); ?>

                PIN: <?php echo e($pin); ?>

            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xarope\htdocs\estagio_projeto\resources\views/myPDF.blade.php ENDPATH**/ ?>